package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.TextView;

//CREATE PIN PAGE//
public class SetPin extends AppCompatActivity
{
    Button go, back;
    Button zero, one, two, three, four, five, six, seven, eight, nine, clear;
    TextView entered;
    String number = "";

    public static String storedPin;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pin);

        entered = findViewById(R.id.setPinEntered);

        go = findViewById(R.id.setPinGo);
        go.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                nextScreen();
            }
        });

        back = findViewById(R.id.setPinBack);
        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toHomeScreen();
            }
        });

        zero = findViewById(R.id.setPin0);
        zero.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberZero();
            }
        });

        one = findViewById(R.id.setPin1);
        one.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberOne();
            }
        });

        two = findViewById(R.id.setPin2);
        two.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberTwo();
            }
        });

        three = findViewById(R.id.setPin3);
        three.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberThree();
            }
        });

        four = findViewById(R.id.setPin4);
        four.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberFour();
            }
        });

        five = findViewById(R.id.setPin5);
        five.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberFive();
            }
        });

        six = findViewById(R.id.setPin6);
        six.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberSix();
            }
        });

        seven = findViewById(R.id.setPin7);
        seven.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberSeven();
            }
        });

        eight = findViewById(R.id.setPin8);
        eight.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberEight();
            }
        });

        nine = findViewById(R.id.setPin9);
        nine.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberNine();
            }
        });

        clear = findViewById(R.id.setPinClear);
        clear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ClearNumbers();
            }
        });

        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(4);
        entered.setFilters(filterArray);

    }

    public void nextScreen()
    {
        Intent intent = new Intent(SetPin.this, ChooseMethods.class);
        AlertDialog.Builder tooShortWarning = new AlertDialog.Builder(SetPin.this);
        if (number.length() < 4)
        {
            tooShortWarning.setTitle("Alert");
            tooShortWarning.setMessage("Pin must be at least 4 digits");
            tooShortWarning.show();
        }
        else
        {
            storedPin = entered.getText().toString();
            startActivity(intent);
        }
    }

    public void toHomeScreen()
    {
        Intent intent = new Intent(SetPin.this, MainActivity.class);
        startActivity(intent);
    }

    public void showNumberZero()
    {
        number = number + "0";
        entered.setText(number);
    }

    public void showNumberOne()
    {
        number = number + "1";
        entered.setText(number);
    }

    public void showNumberTwo()
    {
        number = number + "2";
        entered.setText(number);
    }

    public void showNumberThree()
    {
        number = number + "3";
        entered.setText(number);
    }

    public void showNumberFour()
    {
        number = number + "4";
        entered.setText(number);
    }

    public void showNumberFive()
    {
        number = number + "5";
        entered.setText(number);
    }

    public void showNumberSix()
    {
        number = number + "6";
        entered.setText(number);
    }

    public void showNumberSeven()
    {
        number = number + "7";
        entered.setText(number);
    }

    public void showNumberEight()
    {
        number = number + "8";
        entered.setText(number);
    }

    public void showNumberNine()
    {
        number = number + "9";
        entered.setText(number);
    }

    public void ClearNumbers()
    {
        number = "";
        entered.setText(number);
    }
}