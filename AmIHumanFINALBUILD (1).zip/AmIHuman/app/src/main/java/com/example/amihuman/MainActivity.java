package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

//HOME PAGE//
public class MainActivity extends AppCompatActivity
{
    Button getStarted;
    Button manageInfo;

    ChooseMethods cm = new ChooseMethods();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getStarted = findViewById(R.id.mainGetStarted);
        getStarted.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toSetPin();
            }
        });

        manageInfo = findViewById(R.id.mainManage);
        manageInfo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toCheckPin();
            }
        });
    }

    public void toSetPin()
    {
        Intent intent = new Intent(MainActivity.this, SetPin.class);
        startActivity(intent);
    }

    public void toCheckPin()
    {
        Intent intent = new Intent(MainActivity.this, CheckPin.class);
        startActivity(intent);
    }

}