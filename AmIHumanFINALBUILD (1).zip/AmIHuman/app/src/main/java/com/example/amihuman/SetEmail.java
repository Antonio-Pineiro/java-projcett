package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



//SET EMAIL SCREEN//
public class SetEmail extends AppCompatActivity
{
    Button cancelButton;
    Button doneButton;

    EditText emailTextBox;
    EditText confirmEmailTextBox;

    String email;
    String confirmedEmail;

    public static boolean emailDone;
    public static String storedEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_email);

        EditText emailTextBox = findViewById(R.id.setEmailEntered);
        EditText confirmEmailTextBox = findViewById(R.id.setEmailConfirmEntered);

        cancelButton = findViewById(R.id.setEmailCancel);
        cancelButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                backToChooseMethods();
            }
        });

        doneButton = findViewById(R.id.setEmailDone);
        doneButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                email = emailTextBox.getText().toString();
                confirmedEmail = confirmEmailTextBox.getText().toString();

                if (email.equals(confirmedEmail))
                {
                    backToChooseMethods();
                    emailDone = true;
                    storedEmail = email;
                    //chooseMethods.methodsCountCheck++;
                }
                else
                {
                    AlertDialog.Builder emailDoesntMatch = new AlertDialog.Builder(SetEmail.this);
                    emailDoesntMatch.setTitle("Alert");
                    emailDoesntMatch.setMessage("Emails Do Not Match");
                    emailDoesntMatch.show();

                }
            }
        });

    }

    public void backToChooseMethods()
    {
        Intent intent = new Intent(SetEmail.this, ChooseMethods.class);
        startActivity(intent);
    }
}