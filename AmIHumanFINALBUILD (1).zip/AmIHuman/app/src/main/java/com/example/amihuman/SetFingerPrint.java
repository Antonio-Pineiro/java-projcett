package com.example.amihuman;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.concurrent.Executor;


//SET FINGER PRINT PAGE//
public class SetFingerPrint extends AppCompatActivity
{
    public static boolean fingerPrintDone;
    public boolean fingerPrintScanned;

    Button cancelButton;
    Button scanButton;
    Button doneButton;
    TextView authorizationMssge;

    private Executor executor;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_finger_print);

        doneButton = findViewById(R.id.setFingerDone);
        scanButton = findViewById(R.id.setFingerScan);
        cancelButton = findViewById(R.id.setFingerCancel);
        authorizationMssge = findViewById(R.id.setFingerAuth);

        executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(SetFingerPrint.this, executor, new BiometricPrompt.AuthenticationCallback()
        {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString)
            {
                super.onAuthenticationError(errorCode, errString);
                authorizationMssge.setText("Authentication Error: " + errString);
                authorizationMssge.setTextColor(Color.RED);
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result)
            {
                super.onAuthenticationSucceeded(result);
                authorizationMssge.setText("Success");
                authorizationMssge.setTextColor(Color.GREEN);
                fingerPrintScanned = true;
            }

            @Override
            public void onAuthenticationFailed()
            {
                super.onAuthenticationFailed();
                authorizationMssge.setText("Authentication Failed");
                authorizationMssge.setTextColor(Color.RED);
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Finger Print Authentication")
                .setSubtitle("Scan Finger Print into system")
                .setNegativeButtonText("User App Pass")
                .build();

        scanButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                biometricPrompt.authenticate(promptInfo);
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                backToChooseMethods();
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(fingerPrintScanned == true)
                {
                    fingerPrintDone = true;
                    backToChooseMethods();
                }
                else
                {
                    AlertDialog.Builder noFingerPrint = new AlertDialog.Builder(SetFingerPrint.this);
                    noFingerPrint.setTitle("Alert");
                    noFingerPrint.setMessage("No Finger Print Scan Detected");
                    noFingerPrint.show();
                }
            }
        });
    }

    public void backToChooseMethods()
    {
        Intent intent = new Intent(SetFingerPrint.this, ChooseMethods.class);
        startActivity(intent);
    }


}