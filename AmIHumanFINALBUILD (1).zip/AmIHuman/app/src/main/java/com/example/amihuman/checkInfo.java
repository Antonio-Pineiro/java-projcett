package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class checkInfo extends AppCompatActivity
{
    Button back;

    Button passShow;
    Button passClear;
    TextView passField;
    SetPassword setPass = new SetPassword();

    Button emailShow;
    Button emailClear;
    TextView emailField;
    SetEmail setEmail = new SetEmail();

    Button navButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_info);

        passField = findViewById(R.id.checkInfoPassView);
        emailField = findViewById(R.id.checkInfoEmailView);

        back = findViewById(R.id.checkInfoBack);
        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toHomeScreen();
            }
        });

        passShow = findViewById(R.id.checkInfoShowPass);
        passShow.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if(setPass.storedPassword != null)
                {
                    passField.setText(setPass.storedPassword);
                }
                else
                {
                    AlertDialog.Builder noPass = new AlertDialog.Builder(checkInfo.this);
                    noPass.setTitle("Alert");
                    noPass.setMessage("No password has been set");
                    noPass.show();
                }
            }
        });

        passClear = findViewById(R.id.checkInfoClearPass);
        passClear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                SetPassword.storedPassword = null;
                SetPassword.passDone = false;
                passField.setText(null);
            }
        });

        emailShow = findViewById(R.id.checkInfoShowEmail);
        emailShow.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if(setEmail.storedEmail != null)
                {
                    emailField.setText(setEmail.storedEmail);
                }
                else
                {
                    AlertDialog.Builder noEmail = new AlertDialog.Builder(checkInfo.this);
                    noEmail.setTitle("Alert");
                    noEmail.setMessage("No Email has been set");
                    noEmail.show();
                }
            }
        });

        emailClear = findViewById(R.id.checkInfoClearEmail);
        emailClear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                SetEmail.storedEmail = null;
                SetEmail.emailDone = false;
                emailField.setText(null);
            }
        });


        navButton = findViewById(R.id.checkInfoNav);
        navButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toSettings();
            }
        });

    }

    public void toHomeScreen()
    {
        Intent intent = new Intent(checkInfo.this, MainActivity.class);
        startActivity(intent);
    }

    public void toSettings()
    {
        Intent intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
        startActivity(intent);
    }
}