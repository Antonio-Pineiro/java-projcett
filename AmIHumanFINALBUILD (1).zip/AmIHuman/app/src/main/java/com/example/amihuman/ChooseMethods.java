package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.TextView;

//CHOOSE VERIFICATION METHODS SCREEN//
public class ChooseMethods extends AppCompatActivity
{
    int methodsCountCheck = 0;

    TextView passIndicator;
    TextView emailIndicator;
    TextView fingerPrintIndicator;

    Button passButton;
    Button emailButton;
    Button fpButton;
    Button doneButton;
    Button backButton;

    SetPassword setPass = new SetPassword();
    SetEmail setEmail = new SetEmail();
    SetFingerPrint setFingerPrint = new SetFingerPrint();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_methods);

        passButton = findViewById(R.id.chooseMethodsPassButton);
        passButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toSetPassword();
            }
        });

        emailButton = findViewById(R.id.chooseMethodsEmailButton);
        emailButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toSetEmail();
            }
        });

        fpButton = findViewById(R.id.chooseMethodsFingerButton);
        fpButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toSetFingerPrint();
            }
        });

        passIndicator = findViewById(R.id.chooseMethodsPassText);
        if (setPass.passDone == true)
        {
            passIndicator.setText("DONE");
            passIndicator.setTextColor(Color.GREEN);
            methodsCountCheck++;
        }

        emailIndicator = findViewById(R.id.chooseMethodsEmailText);
        if (setEmail.emailDone == true)
        {
            emailIndicator.setText("DONE");
            emailIndicator.setTextColor(Color.GREEN);
            methodsCountCheck++;
        }

        fingerPrintIndicator = findViewById(R.id.chooseMethodsFingerText);
        if (setFingerPrint.fingerPrintDone == true)
        {
            fingerPrintIndicator.setText("DONE");
            fingerPrintIndicator.setTextColor(Color.GREEN);
            methodsCountCheck++;
        }


        doneButton = findViewById(R.id.chooseMethodsDone);
        doneButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (methodsCountCheck >= 2)
                {
                    toHomePage();
                }
                else
                {
                    AlertDialog.Builder notEnoughMethods = new AlertDialog.Builder(ChooseMethods.this);
                    notEnoughMethods.setTitle("Alert");
                    notEnoughMethods.setMessage("Please Complete At Least 2 Methods");
                    notEnoughMethods.show();
                }
            }
        });

        backButton = findViewById(R.id.chooseMethodsBack);
        backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toPinScreen();
            }
        });
    }

    public void toSetPassword()
    {
        Intent intent = new Intent(ChooseMethods.this, SetPassword.class);
        startActivity(intent);
    }

    public void toSetEmail()
    {
        Intent intent = new Intent(ChooseMethods.this, SetEmail.class);
        startActivity(intent);
    }

    public void toSetFingerPrint()
    {
        Intent intent = new Intent(ChooseMethods.this, SetFingerPrint.class);
        startActivity(intent);
    }

    public void toHomePage()
    {
        Intent intent = new Intent(ChooseMethods.this, MainActivity.class);
        startActivity(intent);
    }

    public void toPinScreen()
    {
        Intent intent = new Intent(ChooseMethods.this, SetPin.class);
        startActivity(intent);
    }

}