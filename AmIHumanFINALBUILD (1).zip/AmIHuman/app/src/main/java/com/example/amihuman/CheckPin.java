package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.TextView;

public class CheckPin extends AppCompatActivity
{
    Button go, back;
    Button zero, one, two, three, four, five, six, seven, eight, nine, clear;
    TextView entered;
    String number = "";

    SetPin setPin = new SetPin();
    public static String enteredPin;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_pin);

        entered = findViewById(R.id.checkPinEntered);

        go = findViewById(R.id.checkPinGo);
        go.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                enteredPin = entered.getText().toString();

                if (setPin.storedPin != null)
                {
                    if (setPin.storedPin.equals(enteredPin))
                    {
                        nextScreen();
                    }
                    else
                    {
                        AlertDialog.Builder doesNotMatch = new AlertDialog.Builder(CheckPin.this);
                        doesNotMatch.setTitle("Alert");
                        doesNotMatch.setMessage("Pin is incorrect");
                        doesNotMatch.show();
                    }
                }
                else
                {
                    AlertDialog.Builder noPin = new AlertDialog.Builder(CheckPin.this);
                    noPin.setTitle("Alert");
                    noPin.setMessage("You did not set a pin yet");
                    noPin.show();
                }
            }
        });

        back = findViewById(R.id.checkPinBack);
        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toHomeScreen();
            }
        });

        zero = findViewById(R.id.checkPin0);
        zero.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberZero();
            }
        });

        one = findViewById(R.id.checkPin1);
        one.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberOne();
            }
        });

        two = findViewById(R.id.checkPin2);
        two.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberTwo();
            }
        });

        three = findViewById(R.id.checkPin3);
        three.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberThree();
            }
        });

        four = findViewById(R.id.checkPin4);
        four.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberFour();
            }
        });

        five = findViewById(R.id.checkPin5);
        five.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberFive();
            }
        });

        six = findViewById(R.id.checkPin6);
        six.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberSix();
            }
        });

        seven = findViewById(R.id.checkPin7);
        seven.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberSeven();
            }
        });

        eight = findViewById(R.id.checkPin8);
        eight.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberEight();
            }
        });

        nine = findViewById(R.id.checkPin9);
        nine.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                showNumberNine();
            }
        });

        clear = findViewById(R.id.checkPinClear);
        clear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ClearNumbers();
            }
        });
    }

    public void nextScreen()
    {
        Intent intent = new Intent(CheckPin.this, checkInfo.class);
        startActivity(intent);
    }

    public void toHomeScreen()
    {
        Intent intent = new Intent(CheckPin.this, MainActivity.class);
        startActivity(intent);
    }

    public void showNumberZero()
    {
        number = number + "0";
        entered.setText(number);
    }

    public void showNumberOne()
    {
        number = number + "1";
        entered.setText(number);
    }

    public void showNumberTwo()
    {
        number = number + "2";
        entered.setText(number);
    }

    public void showNumberThree()
    {
        number = number + "3";
        entered.setText(number);
    }

    public void showNumberFour()
    {
        number = number + "4";
        entered.setText(number);
    }

    public void showNumberFive()
    {
        number = number + "5";
        entered.setText(number);
    }

    public void showNumberSix()
    {
        number = number + "6";
        entered.setText(number);
    }

    public void showNumberSeven()
    {
        number = number + "7";
        entered.setText(number);
    }

    public void showNumberEight()
    {
        number = number + "8";
        entered.setText(number);
    }

    public void showNumberNine()
    {
        number = number + "9";
        entered.setText(number);
    }

    public void ClearNumbers()
    {
        number = "";
        entered.setText(number);
    }
}