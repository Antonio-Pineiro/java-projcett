package com.example.amihuman;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



//SET PASSWORD SCREEN//
public class SetPassword extends AppCompatActivity
{
    Button cancelButton;
    Button doneButton;

    EditText passTextBox;
    EditText confirmPassTextBox;

    String password;
    String confirmedPassword;

    public static boolean passDone;
    public static String storedPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_password);

        passTextBox = findViewById(R.id.setPassEntered);
        confirmPassTextBox = findViewById(R.id.setPassConfirmEntered);

        cancelButton = findViewById(R.id.setPassCancel);
        cancelButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                backToChooseMethods();
            }
        });

        doneButton = findViewById(R.id.setPassDoneButton);
        doneButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                password = passTextBox.getText().toString();
                confirmedPassword = confirmPassTextBox.getText().toString();

                if (password.equals(confirmedPassword))
                {
                    backToChooseMethods();
                    passDone = true;
                    storedPassword = password;
                    //chooseMethods.methodsCountCheck++;
                }
                else
                {
                    AlertDialog.Builder passDoesntMatch = new AlertDialog.Builder(SetPassword.this);
                    passDoesntMatch.setTitle("Alert");
                    passDoesntMatch.setMessage("Passwords Do Not Match");
                    passDoesntMatch.show();

                }

            }
        });

    }

    public void backToChooseMethods()
    {
        Intent intent = new Intent(SetPassword.this, ChooseMethods.class);
        startActivity(intent);
    }
}

